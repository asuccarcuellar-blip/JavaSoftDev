/*Andres Succar
p.29 Aug 31 */
import javax.swing.JOptionPane;


public class HelloDialog {
    public static void main(String[] args)
    {
JOptionPane.showMessageDialog(null, "Hello, world!");

    }
}
